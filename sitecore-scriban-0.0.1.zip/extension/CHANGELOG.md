# Change Log

Sitecore Scriban Syntax Coloring and intellisense for known objects Extension for Visual Studio Code

## 1.0.0
- Initial release